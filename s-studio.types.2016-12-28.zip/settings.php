<?php
$timestamp = 1482917116;

?>